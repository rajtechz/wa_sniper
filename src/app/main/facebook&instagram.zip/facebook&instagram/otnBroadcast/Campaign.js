import React from 'react'

export default function Campaign() {
  return (
    <div>
      <h1> Campaign</h1>
    </div>
  )
}
