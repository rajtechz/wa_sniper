import React from 'react'

export default function MultiMediaPostHeader() {
  return (
    <div>
      <h1> Hello</h1>
    </div>
  )
}
