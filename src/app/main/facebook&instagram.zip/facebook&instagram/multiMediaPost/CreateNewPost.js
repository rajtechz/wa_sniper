import {
  Typography,
  Box,
  TextField,
  Switch,
  FormControlLabel,
} from "@mui/material";
import TelegramIcon from "@mui/icons-material/Telegram";
import * as React from "react";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Grid from "@mui/material/Grid";
import TextSnippetIcon from "@mui/icons-material/TextSnippet";
import useState from "react";
import LinkIcon from "@mui/icons-material/Link";
import CropOriginalIcon from "@mui/icons-material/CropOriginal";
import VideocamIcon from "@mui/icons-material/Videocam";
import Paper from "@mui/material/Paper";
import { Button } from "@mui/material";
const TabPanel = ({ children, value, index }) => {
  return (
    <div hidden={value !== index}>
      {value === index && <Typography component="div">{children}</Typography>}
    </div>
  );
};

export default function CreateNewPost() {
  const [selectedTab, setSelectedTab] = React.useState(0);

  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
  };

  const [isSwitchOn, setIsSwitchOn] = React.useState(true);

  const handleSwitchChange = () => {
    setIsSwitchOn(!isSwitchOn);
  };

  return (
    <>
      <Box sx={{ p: 2 }}>
        <Box sx={{ display: "flex", justifyContent: "space-between" }}>
          <Box
            sx={{
              display: "flex",
              gap: "10px",
              textAlign: "center",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Typography
              sx={{ color: "#000fff", fontSize: "16px", fontWeight: "bold" }}
            >
              <TelegramIcon />
              Multimedia posting
            </Typography>
          </Box>

          <Box sx={{ display: "flex" }}>
            <Typography sx={{ color: "#000fff" }}>Social Posting/</Typography>
            <Typography sx={{ color: "#000fff" }}>Multimedia post/</Typography>
            <Typography>Multimedia post</Typography>
          </Box>
        </Box>
        <Box sx={{ border: "1px solid gray ", p: 2 }}>
          <Grid container>
            <Grid item xs={3}>
              <Paper square>hii</Paper>
            </Grid>
            <Grid item xs={6}>
              <Paper square sx={{ border: "1px solid gray ", p: 1 }}>
                <Box>
                  <Tabs value={selectedTab} onChange={handleTabChange}>
                    <Tab
                      label={
                        <Typography variant="subtitle1">
                          <TextSnippetIcon />
                          <strong>Text</strong>
                        </Typography>
                      }
                    />
                    <Tab
                      label={
                        <Typography variant="subtitle1">
                          <LinkIcon />
                          <strong>Link</strong>
                        </Typography>
                      }
                    />
                    <Tab
                      label={
                        <Typography variant="subtitle1">
                          <CropOriginalIcon />
                          <strong>Image/Carousel</strong>
                        </Typography>
                      }
                    />
                    <Tab
                      label={
                        <Typography variant="subtitle1">
                          <VideocamIcon />
                          <strong>Video</strong>
                        </Typography>
                      }
                    />
                  </Tabs>
                  <Box sx={{ border: "1px solid gray ", p: 2 }}>
                    <TabPanel value={selectedTab} index={0}>
                      <Box>
                        <Typography>Campaign name</Typography>
                        <TextField sx={{ mt: 1 }} size="small" fullWidth />
                      </Box>
                      <Box sx={{ mt: 2 }}>
                        <Typography>Text</Typography>
                        <TextField sx={{ mt: 1 }} size="large" fullWidth />
                      </Box>
                    </TabPanel>
                    <TabPanel value={selectedTab} index={1}>
                      Content of Tab 2
                    </TabPanel>
                    <TabPanel value={selectedTab} index={2}>
                      Content of Tab 3
                    </TabPanel>
                    <TabPanel value={selectedTab} index={3}>
                      Content of Tab 4
                    </TabPanel>
                    <Box mt={2}>
                      <Typography>Posting time</Typography>

                      <FormControlLabel
                        control={
                          <Switch
                            checked={isSwitchOn}
                            onChange={handleSwitchChange}
                          />
                        }
                        label="Post now"
                      />
                      {isSwitchOn && (
                        <Box>
                          <Box sx={{ display: "flex", gap: 1 }}>
                            <Box>
                              <Typography>Schedule time</Typography>
                              <TextField
                                id="outlined-basic"
                                variant="outlined"
                              />
                            </Box>
                            <Box>
                              <Typography>Schedule time</Typography>

                              <TextField
                                id="outlined-basic"
                                variant="outlined"
                              />
                            </Box>
                          </Box>
                          <Box sx={{ display: "flex", gap: 1, mt: 2 }}>
                            <Box>
                              <Typography>Repost this post</Typography>

                              <TextField
                                id="outlined-basic"
                                variant="outlined"
                              />
                            </Box>
                            <Box>
                              <Typography>Time interval</Typography>

                              <TextField
                                id="outlined-basic"
                                variant="outlined"
                              />
                            </Box>
                          </Box>
                        </Box>
                      )}
                    </Box>
                    <Box mt={2}>
                      <Button
                        sx={{ borderRadius: 0 }}
                        variant="contained"
                        color="secondary"
                      >
                        Submit
                      </Button>
                    </Box>
                  </Box>
                </Box>
              </Paper>
            </Grid>
            <Grid item xs={3}>
              <Paper square>kaise ho</Paper>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </>
  );
}
