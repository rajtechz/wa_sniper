import React from 'react'

export default function CtaPostHeader() {
  return (
    <div>
      <h1> hii</h1>
    </div>
  )
}
