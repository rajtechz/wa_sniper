import SequenceAppConfig from "./contacts/SequenceAppConfig";

const sequenceViewConfig = [
    SequenceAppConfig
];
export default sequenceViewConfig;
